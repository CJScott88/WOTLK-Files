# Bartender4

## [4.11.5](https://github.com/Nevcairiel/Bartender4/tree/4.11.5) (2022-09-02)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.11.4...4.11.5) [Previous Releases](https://github.com/Nevcairiel/Bartender4/releases)

- Update Wrath project id checks  
