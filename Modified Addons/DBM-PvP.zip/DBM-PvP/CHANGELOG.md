# <DBM> PvP

## [r135](https://github.com/DeadlyBossMods/DBM-PvP/tree/r135) (2022-08-16)
[Full Changelog](https://github.com/DeadlyBossMods/DBM-PvP/compare/r134...r135) [Previous Releases](https://github.com/DeadlyBossMods/DBM-PvP/releases)

- TOC bump  
- Upd localization.ru.lua (#114)  
    Add three phrases.  
- Fix which locale we're using for flag capture.  
- Better arena timers;  
    Other method was floof.  
- Revert "Improved arena timers utilising UI Widgets"  
- Improved arena timers utilising UI Widgets  
